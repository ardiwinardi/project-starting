$(document).ready(function(){
	$.ajaxSetup({
		headers: {'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')}
	});
	$('.datepicker-input').datepicker({format: 'dd/mm/yyyy'}).on('changeDate', function(ev) { $(this).datepicker('hide'); });
	$('input.number').autoNumeric('init');
	$('[data-confirm]').click(Main.fn_confirm);

	/* setting default validator */
	$.validator.setDefaults({
		highlight: function(element) {
			$(element).closest('.form-group').addClass('has-error');
		},
		unhighlight: function(element) {
			$(element).closest('.form-group').removeClass('has-error');
		},
		errorElement: 'span',
		errorClass: 'help-block',
		showErrors: function(errorMap, errorList) {
			$.each(this.validElements(), function (index, element) {
				var $element = $(element);
				$element.data("title", "").removeClass("error").tooltip("destroy");
				$element.closest('.form-group').removeClass('has-error');
				
			});
			$.each(errorList, function (index, error) {
				var $element = $(error.element);
				$element.tooltip("destroy").data("title", error.message).addClass("error").tooltip();
				$element.closest('.form-group').addClass('has-error');
			});
		}
	});
});

var Main = {
	initForm:function(id,opt){
		setRequiredSign(opt.rules);
		$('#'+id).validate(opt);
		
		function setRequiredSign(rules){
			for(var key in rules){
				var val = rules[key];
				if(key.indexOf('[]') === -1){
					var $element = $('#'+key);
					var $label = $element.closest('.form-group').find('label');
					$label.html($label.text()+'<span class=\"text-danger\" title=\"harus diisi\">*</span>');
				}
			}
		}
	},
	fn_confirm : function(){
		if(confirm($(this).attr('data-confirm')) === false) return false;
	},
}
