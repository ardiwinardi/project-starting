$(document).ready(function(){
	
	/* setting default validator */
	$.validator.setDefaults({
		highlight: function(element) {
			$(element).closest('.form-group').addClass('has-error');
		},
		unhighlight: function(element) {
			$(element).closest('.form-group').removeClass('has-error');
		},
		errorElement: 'span',
		errorClass: 'help-block',
		showErrors: function(errorMap, errorList) {
			$.each(this.validElements(), function (index, element) {
				var $element = $(element);
				$element.data("title", "").removeClass("error").tooltip("destroy");
				$element.closest('.form-group').removeClass('has-error');
				
			});
			$.each(errorList, function (index, error) {
				var $element = $(error.element);
				$element.tooltip("destroy").data("title", error.message).addClass("error").tooltip();
				$element.closest('.form-group').addClass('has-error');
			});
		}
	});
});
