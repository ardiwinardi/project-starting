<div class="col-lg-12">
	<div class="panel panel-default">
		<div class="panel-heading">
			<b>
				<?=$title?> 
			</b>
		</div>
	</div>
</div>
